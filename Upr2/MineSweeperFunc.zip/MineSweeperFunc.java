import java.util.Scanner;








public class MineSweeperFunc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Board obj=new Board();
		int [][] arr=new int[3][3];
		System.out.println(arr.length);
		int a;
		Scanner input=new Scanner(System.in);//we make a new scanner var
        a=input.nextInt();
        System.out.println(a);*/
		Game obj=new Game();
	}

}
